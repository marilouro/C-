﻿using System;
public class Exercicio1
{
    public static void Main()
    {
        int convidadosNoivo = 300;
        int convidadosNoiva = 600;
        int convidadosPresentesNoivo = 405;
        int convidadosPresentesNoiva = 400;

        if(convidadosNoivo > convidadosNoiva)
        {
            Console.WriteLine("A quantidade de convidados do noivo é maior que o da noiva");
        }else
        {
            Console.WriteLine("A quantidade de convidados da noiva é maior que o do noivo");
        }

        if(convidadosPresentesNoivo > convidadosPresentesNoiva)
        {
            Console.WriteLine("Existem mais pessoas, pois existem mais convidados do noivo que da noiva");
        }
        else
        {
            Console.WriteLine("Existem mais pessoas, pois existem mais convidados da noiva que do noivo");
        }
    }
};
