﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Lista_com_List
{
    internal class Program
    {
        static void Main(string[] args)
        {
             List <string> Convidados = new List<string> ();

            Convidados.Add("Mariana");
            Convidados.Add("Andre");
            Convidados.Add("Rafael");
            Convidados.Add("Bruna");
            Convidados.Add("Jose");
            Convidados.Add("Ana");
            Convidados.Add("Guilherme");

            Console.WriteLine("Quantidade de pessoas na lista: " + Convidados.Count + ". Nome dos convidados: ");
            foreach (string item in Convidados)
            {
                Console.WriteLine(item);
            }

            Console.ReadLine();

        }
    }
}
