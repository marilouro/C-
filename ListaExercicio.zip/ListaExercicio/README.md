Exercicio 1
Faca um programa que possua as seguinte informacoes o numero de convidados do noivo e da 
noiva para festa, e o numero de convidados presente do noivo e da noiva, utileze ao menos 
uma vez cada um dos operadores condicionais para comparacoes entre as informacoes exibir o 
resultados sobre essas comparacoes.


Exercicio 2
a)Desenvolvam um programa que armazene uma lista de convidados utilizando um array.
B)Desenvolvam uma outra versao do programa de lista de convidados agora usando List.


Exercicio 3
Desenvolva um programa que a entrada seja uma lista de frutas (entrada pode estar fixa no 
codigo ou vir pelo console) de modo que as frutas devem estar escritas em minusculo e 
separados por virgula, para cada fruta DIFERENTE na entrada adicione num objeto lista o nome 
da fruta com o primeiro caracter Maisculo e o restante minusculo e apos isso utilizando a lista 
imprima cada uma das strings na lista.
OBS: frutas repetidas não devem entrar na lista
